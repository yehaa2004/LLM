import { useState, useRef } from "react";
import { createRoot } from "react-dom/client";
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  ScatterChart, Scatter, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer,
} from "recharts";

// ── Palette ──────────────────────────────────────────────────────────────────
const C = {
  bg: "#0d1117",
  surface: "#161b22",
  border: "#30363d",
  accent: "#58a6ff",
  accentDim: "#1f3a5f",
  green: "#3fb950",
  muted: "#8b949e",
  text: "#e6edf3",
  textDim: "#7d8590",
  chartColors: ["#58a6ff","#3fb950","#f78166","#d2a8ff","#ffa657","#79c0ff"],
};

const css = `
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: ${C.bg}; color: ${C.text}; font-family: 'Inter', sans-serif; min-height: 100vh; }
  #root { display: flex; flex-direction: column; min-height: 100vh; }

  .header { 
    background: ${C.surface}; border-bottom: 1px solid ${C.border};
    padding: 16px 32px; display: flex; align-items: center; gap: 12px;
  }
  .header-icon { font-size: 22px; }
  .header h1 { font-size: 17px; font-weight: 600; color: ${C.text}; }
  .header span { font-size: 13px; color: ${C.muted}; }

  .main { display: flex; flex: 1; gap: 0; }

  /* Sidebar */
  .sidebar {
    width: 300px; min-width: 260px; background: ${C.surface};
    border-right: 1px solid ${C.border}; padding: 24px 20px;
    display: flex; flex-direction: column; gap: 24px;
  }
  .sidebar-section h2 { font-size: 11px; font-weight: 600; color: ${C.muted};
    text-transform: uppercase; letter-spacing: .08em; margin-bottom: 12px; }

  .upload-area {
    border: 1.5px dashed ${C.border}; border-radius: 10px;
    padding: 24px 16px; text-align: center; cursor: pointer;
    transition: border-color .2s, background .2s;
  }
  .upload-area:hover, .upload-area.drag { border-color: ${C.accent}; background: ${C.accentDim}22; }
  .upload-area .upload-icon { font-size: 28px; margin-bottom: 8px; }
  .upload-area p { font-size: 13px; color: ${C.muted}; line-height: 1.5; }
  .upload-area strong { color: ${C.accent}; }

  .dataset-card {
    background: ${C.bg}; border: 1px solid ${C.border}; border-radius: 8px; padding: 14px;
  }
  .dataset-card .dc-name { font-size: 13px; font-weight: 600; color: ${C.green}; margin-bottom: 6px; display: flex; align-items: center; gap: 6px; }
  .dataset-card .dc-stat { font-size: 12px; color: ${C.muted}; margin-bottom: 4px; }
  .dc-cols { display: flex; flex-wrap: wrap; gap: 4px; margin-top: 8px; }
  .dc-col { font-size: 11px; background: ${C.accentDim}; color: ${C.accent};
    border-radius: 4px; padding: 2px 7px; font-family: 'JetBrains Mono', monospace; }

  .example-qs { display: flex; flex-direction: column; gap: 6px; }
  .example-q {
    font-size: 12px; color: ${C.muted}; background: ${C.bg};
    border: 1px solid ${C.border}; border-radius: 6px; padding: 8px 10px;
    cursor: pointer; transition: color .15s, border-color .15s;
    text-align: left; width: 100%;
  }
  .example-q:hover { color: ${C.accent}; border-color: ${C.accent}; }

  /* Content */
  .content { flex: 1; display: flex; flex-direction: column; padding: 24px 28px; gap: 20px; overflow-y: auto; }

  .ask-bar { display: flex; gap: 10px; }
  .ask-input {
    flex: 1; background: ${C.surface}; border: 1.5px solid ${C.border};
    border-radius: 10px; padding: 12px 16px; color: ${C.text}; font-size: 14px;
    font-family: 'Inter', sans-serif; outline: none; transition: border-color .2s;
  }
  .ask-input:focus { border-color: ${C.accent}; }
  .ask-input::placeholder { color: ${C.textDim}; }

  .btn {
    background: ${C.accent}; color: #0d1117; border: none; border-radius: 10px;
    padding: 12px 22px; font-size: 14px; font-weight: 600; cursor: pointer;
    transition: opacity .15s; white-space: nowrap;
  }
  .btn:hover { opacity: .85; }
  .btn:disabled { opacity: .4; cursor: default; }
  .btn-ghost {
    background: transparent; color: ${C.muted}; border: 1px solid ${C.border};
    border-radius: 8px; padding: 6px 14px; font-size: 12px; cursor: pointer;
    transition: color .15s, border-color .15s;
  }
  .btn-ghost.active, .btn-ghost:hover { color: ${C.accent}; border-color: ${C.accent}; }

  .result-card {
    background: ${C.surface}; border: 1px solid ${C.border}; border-radius: 12px; overflow: hidden;
  }
  .result-header { padding: 16px 20px; border-bottom: 1px solid ${C.border}; display: flex; align-items: flex-start; justify-content: space-between; gap: 16px; }
  .result-answer { font-size: 14px; color: ${C.text}; line-height: 1.6; flex: 1; }
  .result-tabs { display: flex; gap: 6px; padding: 12px 20px; border-bottom: 1px solid ${C.border}; }
  .result-body { padding: 20px; }

  /* Table */
  .data-table { width: 100%; border-collapse: collapse; font-size: 13px; }
  .data-table th {
    text-align: left; padding: 8px 12px; color: ${C.muted};
    font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: .06em;
    border-bottom: 1px solid ${C.border};
  }
  .data-table td { padding: 9px 12px; border-bottom: 1px solid ${C.border}22; font-family: 'JetBrains Mono', monospace; font-size: 12px; }
  .data-table tr:last-child td { border-bottom: none; }
  .data-table tr:hover td { background: ${C.accentDim}22; }

  .loading { display: flex; align-items: center; gap: 10px; color: ${C.muted}; font-size: 14px; padding: 32px 0; }
  .spinner { width: 18px; height: 18px; border: 2px solid ${C.border}; border-top-color: ${C.accent}; border-radius: 50%; animation: spin .7s linear infinite; }
  @keyframes spin { to { transform: rotate(360deg); } }

  .empty-state { text-align: center; padding: 64px 0; color: ${C.textDim}; }
  .empty-state .ei { font-size: 40px; margin-bottom: 12px; }
  .empty-state p { font-size: 14px; line-height: 1.6; }

  .error-msg { background: #3d1f1f; border: 1px solid #6e2c2c; border-radius: 8px; padding: 12px 16px; font-size: 13px; color: #f78166; }
`;

// ── Chart renderer ───────────────────────────────────────────────────────────
function Chart({ type, data, columns }) {
  if (!data.length || columns.length < 2) return null;
  const [xKey, yKey] = columns;

  const commonProps = {
    data,
    margin: { top: 10, right: 20, left: 0, bottom: 60 },
  };

  const axis = (
    <>
      <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
      <XAxis dataKey={xKey} tick={{ fill: C.muted, fontSize: 11 }} angle={-35} textAnchor="end" />
      <YAxis tick={{ fill: C.muted, fontSize: 11 }} />
      <Tooltip contentStyle={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 8, color: C.text }} />
      <Legend wrapperStyle={{ color: C.muted, fontSize: 12 }} />
    </>
  );

  if (type === "line") return (
    <ResponsiveContainer width="100%" height={320}>
      <LineChart {...commonProps}>
        {axis}
        <Line dataKey={yKey} stroke={C.accent} strokeWidth={2} dot={false} />
      </LineChart>
    </ResponsiveContainer>
  );

  if (type === "pie") return (
    <ResponsiveContainer width="100%" height={320}>
      <PieChart>
        <Pie data={data} dataKey={yKey} nameKey={xKey} outerRadius={120} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
          {data.map((_, i) => <Cell key={i} fill={C.chartColors[i % C.chartColors.length]} />)}
        </Pie>
        <Tooltip contentStyle={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 8 }} />
      </PieChart>
    </ResponsiveContainer>
  );

  if (type === "scatter") return (
    <ResponsiveContainer width="100%" height={320}>
      <ScatterChart margin={{ top: 10, right: 20, left: 0, bottom: 20 }}>
        <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
        <XAxis dataKey={xKey} tick={{ fill: C.muted, fontSize: 11 }} name={xKey} />
        <YAxis dataKey={yKey} tick={{ fill: C.muted, fontSize: 11 }} name={yKey} />
        <Tooltip contentStyle={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 8 }} />
        <Scatter data={data} fill={C.accent} />
      </ScatterChart>
    </ResponsiveContainer>
  );

  // Default: bar
  return (
    <ResponsiveContainer width="100%" height={320}>
      <BarChart {...commonProps}>
        {axis}
        <Bar dataKey={yKey} radius={[4, 4, 0, 0]}>
          {data.map((_, i) => <Cell key={i} fill={C.chartColors[i % C.chartColors.length]} />)}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

// ── DataTable ────────────────────────────────────────────────────────────────
function DataTable({ data, columns }) {
  if (!data.length) return <p style={{ color: C.muted, fontSize: 13 }}>No data.</p>;
  return (
    <div style={{ overflowX: "auto" }}>
      <table className="data-table">
        <thead>
          <tr>{columns.map(c => <th key={c}>{c}</th>)}</tr>
        </thead>
        <tbody>
          {data.map((row, i) => (
            <tr key={i}>
              {columns.map(c => <td key={c}>{row[c] ?? "—"}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ── Main App ─────────────────────────────────────────────────────────────────
const EXAMPLES = [
  "Show average temperature for each device",
  "Which device consumed the most energy?",
  "Show energy consumption over time",
  "Devices with humidity above 70%",
  "Top 5 devices by energy consumption",
  "Compare temperature and humidity",
];

export default function App() {
  const [dataset, setDataset] = useState(null);
  const [question, setQuestion] = useState("");
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [view, setView] = useState("chart"); // "chart" | "table"
  const [drag, setDrag] = useState(false);
  const fileRef = useRef();

  async function handleFile(file) {
    if (!file) return;
    setUploading(true);
    setError("");
    const fd = new FormData();
    fd.append("file", file);
    try {
      const res = await fetch("/upload", { method: "POST", body: fd });
      if (!res.ok) throw new Error((await res.json()).detail);
      const info = await res.json();
      setDataset(info);
      setResult(null);
    } catch (e) {
      setError(e.message);
    } finally {
      setUploading(false);
    }
  }

  async function handleAsk() {
    if (!question.trim() || !dataset) return;
    setLoading(true);
    setError("");
    setResult(null);
    try {
      const res = await fetch("/ask", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question }),
      });
      const data = await res.json();
      setResult(data);
      setView(data.chart !== "table" ? "chart" : "table");
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <style>{css}</style>
      <div className="header">
        <span className="header-icon">📡</span>
        <div>
          <h1>IoT Data Intelligence</h1>
          <span>Natural language analytics — powered by local LLM</span>
        </div>
      </div>

      <div className="main">
        {/* Sidebar */}
        <aside className="sidebar">
          <div className="sidebar-section">
            <h2>Dataset</h2>
            {!dataset ? (
              <div
                className={`upload-area ${drag ? "drag" : ""}`}
                onClick={() => fileRef.current.click()}
                onDragOver={e => { e.preventDefault(); setDrag(true); }}
                onDragLeave={() => setDrag(false)}
                onDrop={e => { e.preventDefault(); setDrag(false); handleFile(e.dataTransfer.files[0]); }}
              >
                <div className="upload-icon">🗂️</div>
                {uploading
                  ? <p>Uploading…</p>
                  : <p>Drop a <strong>CSV or Excel</strong> file here, or click to browse</p>
                }
                <input ref={fileRef} type="file" accept=".csv,.xlsx,.xls" style={{ display: "none" }}
                  onChange={e => handleFile(e.target.files[0])} />
              </div>
            ) : (
              <div className="dataset-card">
                <div className="dc-name">✅ {dataset.filename}</div>
                <div className="dc-stat">{dataset.rows.toLocaleString()} rows · {dataset.columns.length} columns</div>
                <div className="dc-cols">
                  {dataset.columns.map(c => <span key={c} className="dc-col">{c}</span>)}
                </div>
                <button className="btn-ghost" style={{ marginTop: 12 }} onClick={() => { setDataset(null); setResult(null); }}>
                  Change file
                </button>
              </div>
            )}
          </div>

          {dataset && (
            <div className="sidebar-section">
              <h2>Example questions</h2>
              <div className="example-qs">
                {EXAMPLES.map(q => (
                  <button key={q} className="example-q" onClick={() => setQuestion(q)}>
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}
        </aside>

        {/* Content */}
        <main className="content">
          {/* Ask bar */}
          <div className="ask-bar">
            <input
              className="ask-input"
              placeholder={dataset ? "Ask a question about your data…" : "Upload a dataset first…"}
              value={question}
              disabled={!dataset}
              onChange={e => setQuestion(e.target.value)}
              onKeyDown={e => e.key === "Enter" && handleAsk()}
            />
            <button className="btn" onClick={handleAsk} disabled={!dataset || loading || !question.trim()}>
              {loading ? "Thinking…" : "Ask"}
            </button>
          </div>

          {error && <div className="error-msg">⚠️ {error}</div>}

          {loading && (
            <div className="loading">
              <div className="spinner" />
              Querying local LLM + running Pandas…
            </div>
          )}

          {result && !loading && (
            <div className="result-card">
              <div className="result-header">
                <div className="result-answer">💬 {result.answer}</div>
              </div>

              {result.data?.length > 0 && (
                <>
                  <div className="result-tabs">
                    {result.chart !== "table" && (
                      <button className={`btn-ghost ${view === "chart" ? "active" : ""}`} onClick={() => setView("chart")}>
                        📊 Chart
                      </button>
                    )}
                    <button className={`btn-ghost ${view === "table" ? "active" : ""}`} onClick={() => setView("table")}>
                      📋 Table
                    </button>
                    <span style={{ marginLeft: "auto", fontSize: 12, color: C.muted, alignSelf: "center" }}>
                      {result.data.length} rows
                    </span>
                  </div>
                  <div className="result-body">
                    {view === "chart" && result.chart !== "table"
                      ? <Chart type={result.chart} data={result.data} columns={result.columns} />
                      : <DataTable data={result.data} columns={result.columns} />
                    }
                  </div>
                </>
              )}
            </div>
          )}

          {!result && !loading && (
            <div className="empty-state">
              <div className="ei">🔍</div>
              <p>
                {dataset
                  ? "Ask a question above to analyse your data."
                  : "Upload a CSV or Excel file to get started."}
              </p>
            </div>
          )}
        </main>
      </div>
    </>
  );
}

createRoot(document.getElementById("root")).render(<App />);
