"""
Simple RAG: embeds dataset schema info into FAISS so the LLM
gets relevant column context for each user question.
"""
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer

_model = SentenceTransformer("all-MiniLM-L6-v2")

_index: faiss.IndexFlatL2 | None = None
_chunks: list[str] = []


def build_index(schema_chunks: list[str]):
    global _index, _chunks
    _chunks = schema_chunks
    vecs = _model.encode(schema_chunks, convert_to_numpy=True).astype("float32")
    _index = faiss.IndexFlatL2(vecs.shape[1])
    _index.add(vecs)


def retrieve(query: str, k: int = 4) -> str:
    if _index is None or not _chunks:
        return ""
    q_vec = _model.encode([query], convert_to_numpy=True).astype("float32")
    k = min(k, len(_chunks))
    _, ids = _index.search(q_vec, k)
    return "\n".join(_chunks[i] for i in ids[0] if i < len(_chunks))


def schema_chunks(df) -> list[str]:
    """Turn a DataFrame into small text chunks describing schema + samples."""
    import pandas as pd
    chunks = [f"Dataset has {len(df)} rows and {len(df.columns)} columns."]
    for col in df.columns:
        dtype = str(df[col].dtype)
        sample = df[col].dropna().head(3).tolist()
        nunique = df[col].nunique()
        chunk = (
            f"Column '{col}': type={dtype}, unique_values={nunique}, "
            f"sample={sample}"
        )
        if pd.api.types.is_numeric_dtype(df[col]):
            chunk += (
                f", min={df[col].min():.2f}, max={df[col].max():.2f}, "
                f"mean={df[col].mean():.2f}"
            )
        chunks.append(chunk)
    return chunks
