"""
Local LLM via Hugging Face Transformers (no Ollama, no API key).

Default model: Qwen/Qwen2.5-1.5B-Instruct  (~3 GB, runs on CPU)

Other good options (change MODEL below):
  - "microsoft/Phi-3-mini-4k-instruct"        (~7 GB, very capable)
  - "mistralai/Mistral-7B-Instruct-v0.3"      (~14 GB, needs ~8 GB RAM)
  - "google/gemma-2-2b-it"                    (~5 GB)
  - "TinyLlama/TinyLlama-1.1B-Chat-v1.0"     (~2 GB, fastest/weakest)

The model is downloaded once to ~/.cache/huggingface/ on first run.
"""
import json, re, torch
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline

MODEL = "Qwen/Qwen2.5-1.5B-Instruct"

SYSTEM = """You are a data analysis assistant. Given a user question and dataset schema,
return ONLY a valid JSON object — no markdown, no explanation, nothing else.

Use this exact structure:
{
  "operation": "group_by" | "filter" | "aggregate" | "sort" | "top_n" | "time_series" | "compare",
  "group_by_col": "column_name or null",
  "filter_col": "column_name or null",
  "filter_op": ">" | "<" | ">=" | "<=" | "==" | "!=" | "contains" | null,
  "filter_val": value_or_null,
  "metric_col": "numeric column to measure or null",
  "aggregation": "sum" | "mean" | "min" | "max" | "count" | null,
  "sort_col": "column_name or null",
  "sort_desc": true | false,
  "limit": number_or_null,
  "chart": "bar" | "line" | "pie" | "scatter" | "table",
  "answer_template": "Short human-readable summary of what will be shown"
}

Rules:
- Only use column names that exist in the provided schema.
- For time-series questions, use operation=time_series and set group_by_col to the timestamp column.
- For comparisons, use operation=compare.
- If the question cannot be answered from the data, return {"error": "reason"}.
- Return JSON only. No prose, no markdown fences."""

# ── Load model once at startup ────────────────────────────────────────────────
print(f"[llm] Loading {MODEL} …")
_device = "cuda" if torch.cuda.is_available() else "cpu"

_tokenizer = AutoTokenizer.from_pretrained(MODEL)
_model = AutoModelForCausalLM.from_pretrained(
    MODEL,
    torch_dtype=torch.float16 if _device == "cuda" else torch.float32,
    device_map="auto",          # spreads across GPU/CPU automatically
    low_cpu_mem_usage=True,
)

_pipe = pipeline(
    "text-generation",
    model=_model,
    tokenizer=_tokenizer,
    device_map="auto",
    max_new_tokens=512,
    do_sample=False,            # greedy — more deterministic for JSON output
    temperature=None,
    top_p=None,
)
print(f"[llm] Model ready on {_device}")


# ── Inference ─────────────────────────────────────────────────────────────────
def ask_llm(question: str, context: str) -> dict:
    messages = [
        {"role": "system", "content": SYSTEM},
        {"role": "user",   "content": f"Schema context:\n{context}\n\nUser question: {question}"},
    ]

    # Use chat template if the tokenizer supports it
    try:
        prompt_text = _tokenizer.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True
        )
    except Exception:
        # Fallback: simple concatenation
        prompt_text = f"{SYSTEM}\n\nSchema context:\n{context}\n\nUser question: {question}\n\nJSON:"

    raw = ""
    try:
        out = _pipe(prompt_text)
        generated = out[0]["generated_text"]
        # Strip the input prompt from output
        raw = generated[len(prompt_text):].strip()
        raw = re.sub(r"```json|```", "", raw).strip()
        return json.loads(raw)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", raw, re.DOTALL)
        if match:
            try:
                return json.loads(match.group())
            except Exception:
                pass
        return {"error": f"Model returned non-JSON: {raw[:200]}"}
    except Exception as e:
        return {"error": str(e)}
