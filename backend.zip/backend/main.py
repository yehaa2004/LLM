"""
FastAPI backend for IoT LLM Tool.
Endpoints:
  POST /upload  — upload CSV/Excel, build RAG index
  POST /ask     — natural language question → structured result
"""
import io, json
import numpy as np
import pandas as pd
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

import rag, llm

app = FastAPI(title="IoT LLM Tool")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory dataset store (single user / demo)
_df: pd.DataFrame | None = None
_dataset_info: dict = {}


# ── Upload ──────────────────────────────────────────────────────────────────

@app.post("/upload")
async def upload(file: UploadFile = File(...)):
    global _df, _dataset_info
    content = await file.read()
    name = file.filename or ""

    try:
        if name.endswith(".csv"):
            _df = pd.read_csv(io.BytesIO(content))
        elif name.endswith((".xlsx", ".xls")):
            _df = pd.read_excel(io.BytesIO(content))
        else:
            raise HTTPException(400, "Only CSV or Excel files are supported.")
    except Exception as e:
        raise HTTPException(400, f"Could not read file: {e}")

    # Parse timestamps
    for col in _df.columns:
        if "time" in col.lower() or "date" in col.lower():
            try:
                _df[col] = pd.to_datetime(_df[col])
            except Exception:
                pass

    # Build RAG index from schema
    chunks = rag.schema_chunks(_df)
    rag.build_index(chunks)

    _dataset_info = {
        "filename": name,
        "rows": len(_df),
        "columns": list(_df.columns),
        "dtypes": {c: str(_df[c].dtype) for c in _df.columns},
    }
    return _dataset_info


# ── Ask ──────────────────────────────────────────────────────────────────────

class Question(BaseModel):
    question: str


@app.post("/ask")
async def ask(body: Question):
    if _df is None:
        raise HTTPException(400, "No dataset uploaded yet.")

    context = rag.retrieve(body.question)
    plan = llm.ask_llm(body.question, context)

    if "error" in plan:
        return {"answer": f"Sorry: {plan['error']}", "data": [], "columns": [], "chart": "table"}

    try:
        result = execute_plan(plan, _df)
    except Exception as e:
        return {"answer": f"Could not process: {e}", "data": [], "columns": [], "chart": "table"}

    return result


# ── Plan executor (safe Pandas ops only) ─────────────────────────────────────

def execute_plan(plan: dict, df: pd.DataFrame) -> dict:
    op = plan.get("operation", "aggregate")
    chart = plan.get("chart", "table")
    answer = plan.get("answer_template", "Here are the results.")
    limit = plan.get("limit")

    working = df.copy()

    # --- Filter ---
    fc = plan.get("filter_col")
    fop = plan.get("filter_op")
    fval = plan.get("filter_val")
    if fc and fop and fval is not None and fc in working.columns:
        working = apply_filter(working, fc, fop, fval)

    # --- Group by + aggregate ---
    gc = plan.get("group_by_col")
    mc = plan.get("metric_col")
    agg = plan.get("aggregation", "mean")

    if op in ("group_by", "top_n", "time_series", "compare"):
        if gc and gc in working.columns:
            if mc and mc in working.columns:
                result_df = working.groupby(gc)[mc].agg(agg).reset_index()
                result_df.columns = [gc, mc]
            else:
                result_df = working.groupby(gc).size().reset_index(name="count")
                mc = "count"
        else:
            result_df = working
    elif op == "filter":
        result_df = working
    elif op == "sort":
        sc = plan.get("sort_col") or mc
        if sc and sc in working.columns:
            result_df = working.sort_values(sc, ascending=not plan.get("sort_desc", True))
        else:
            result_df = working
    else:  # aggregate scalar
        if mc and mc in working.columns:
            val = getattr(working[mc], agg or "mean")()
            return {
                "answer": f"{answer} — {mc} {agg}: {round(float(val), 2)}",
                "data": [{mc: round(float(val), 2)}],
                "columns": [mc],
                "chart": "table",
            }
        result_df = working

    # --- Sort output ---
    sc = plan.get("sort_col") or mc
    if sc and sc in result_df.columns:
        result_df = result_df.sort_values(sc, ascending=not plan.get("sort_desc", True))

    # --- Limit ---
    if limit:
        result_df = result_df.head(int(limit))

    # Serialise (handle Timestamps, NaN, etc.)
    result_df = result_df.reset_index(drop=True)
    data = json.loads(result_df.to_json(orient="records", date_format="iso"))

    return {
        "answer": answer,
        "data": data,
        "columns": list(result_df.columns),
        "chart": chart,
    }


def apply_filter(df: pd.DataFrame, col: str, op: str, val) -> pd.DataFrame:
    s = df[col]
    try:
        if op == ">":   return df[s > val]
        if op == "<":   return df[s < val]
        if op == ">=":  return df[s >= val]
        if op == "<=":  return df[s <= val]
        if op == "==":  return df[s == val]
        if op == "!=":  return df[s != val]
        if op == "contains": return df[s.astype(str).str.contains(str(val), case=False)]
    except Exception:
        pass
    return df


# ── Dataset info ─────────────────────────────────────────────────────────────

@app.get("/info")
def info():
    return _dataset_info or {}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
